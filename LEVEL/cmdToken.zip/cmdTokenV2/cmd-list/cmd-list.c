#include "./cmd-list.h"

//char* funcName;
//char** params;
//int params_size;

//TODO write ./info.txt, make transformation to selected
//variable type eg char* ("true ") to bool (true or 1)
//char* (10 50 5) to int (10505)
//TODO end up cmd list

/*
bool requireArgs(int reqSize, char** allowedTypes, char** details ){
	//function verifing function's parameters
	if(params_size == reqSize){
		int i;
e		for(i=0;i<reqSize;i++){
			if(allowedTypes[i] == "int"){
				int j;
				for(j=0; j<strlen(params[i]); j++){

				}
			}
			if(allowedTypes[i] == "string"){
				return true;
			}
		}
	}else{
		return false;
	}
	return false;
}
*/

void execute(){
	int i=0;
	const int exels_size = 6;
	const char exels[exels_size][20]={
		"loop",     //APPLICATION'S LOOP MENAGMENT
		"exit",     //EXIT LOOP
		"echo",     //WRITE ON SCREEN ARGUMENTS
		"addexe",   //ADD NAMES AND PATHS TO EXE FILES
		"exe-list", //WRITE NAMES AND PATHS TO EXE FILES
		"exe"       //EXECUTE SELECTED EXE FILES
	};
	//printf("FUNC NAME: %s\n", funcName);
	//printf("%s\n", exels[0]);
	if(strcmp(APPLICATION.function, exels[0]) == 0){
		if(APPLICATION.arg_size >= 1){
			if(strcmp(APPLICATION.arguments[0], "true") == 0){
				APPLICATION.LOOP = true;
			}
			if(strcmp(APPLICATION.arguments[0], "false") == 0){
				APPLICATION.LOOP = false;
			}
		}
	}
	else if(strcmp(APPLICATION.function, exels[1]) == 0){
		APPLICATION.LOOP = false;
	}
	else if(strcmp(APPLICATION.function, exels[2]) == 0){
		//printf("echo executing\n");
		for(i=0; i<APPLICATION.arg_size; i++){
			printf("%s\n", APPLICATION.arguments[i]);
		}
	}
	else if(strcmp(APPLICATION.function, exels[3]) == 0){
		if(APPLICATION.arg_size >= 2 && APPLICATION.arg_size % 2 == 0){
                	FILE *addPath;
			addPath = fopen("./cmd-list/exe.list", "a");
			if(addPath != NULL){
			//write
				for(i=0; i<APPLICATION.arg_size; i+=2){
					fprintf(addPath, "%s", APPLICATION.arguments[i]);
					fprintf(addPath, "[%s]\n", APPLICATION.arguments[i+1]);
				}
			}else{printf("FOPEN DOESNT WORK\n");}

			fclose(addPath);
		}
        }
	else if(strcmp(APPLICATION.function, exels[4]) == 0){
		i=0;

		FILE *getFile;
		getFile = fopen("./cmd-list/exe.list", "r");

		//read
		unsigned int nameLength=16;
		unsigned int pathLength=16;
		unsigned int size=4;

		char** name = (char**) malloc(size*sizeof(char*));
                char** path = (char**) malloc(size*sizeof(char*));

		while(i<size){
			name[i] = (char*) malloc(nameLength*sizeof(char));
			strcpy(name[i], "");
			path[i] = (char*) malloc(pathLength*sizeof(char));
			strcpy(path[i], "");
		}

		strcpy(name, "");
		strcpy(path, "");
		int nameIndex = 0;
		int pathIndex = 0;
		int sizeIndex;

		char readChar[1];
		//fscanf(getFile, "%c", readChar);
		//printf("%d\n", (!(feof(getFile))));
		while(i<200){
			fscanf(getFile, "%c", readChar);
			//readChar = fgetc(getFile);
			if (feof(getFile)){
				printf("END OF FILE\n");
				break;
			}
			if(readChar[0] == '\n'){
				printf("NEW LINE\n");
				break;
			}
			printf("%c", readChar[0]);
			if(readChar[0] == '['){
				while(readChar[0] != ']'){
					fscanf(getFile, "%c", readChar);
					//readChar = fgetc(getFile);
					pathIndex++;
					if(pathIndex == pathLength){
						pathLength+=pathLength;
						path[i] = (char*) realloc(path, pathLength);
					}
					if(readChar[0] != ']'){
						addChar(path[i], readChar[0]);
					}
				}
			}else{
				nameIndex++;
				if(nameIndex == nameLength){
                                     	nameLength+=nameLength;
                                	name = (char*) realloc(name, nameLength);
                        	}
				addChar(name, readChar[0]);
			}
			//fseek(getFile, 1, 1);
			printf("%d\n", i);
			i++;
		}
		fclose(getFile);
		printf("\n");
		printf("%s\n", name);
		printf("%s\n", path);
	}

	else{
		//unknown function
		printf("UNKNOWN FUNCTION \"%s\"!\n", APPLICATION.function);
		for(i=0; i<exels_size; i++){
			printf("%s\n", exels[i]);
		}
	}
}

