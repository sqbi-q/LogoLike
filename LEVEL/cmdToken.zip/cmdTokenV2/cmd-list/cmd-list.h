#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "../tokenizer/addChar.h"

#ifndef _CMDLIST_H_
#define _CMDLIST_H_

typedef struct app_vars{
	char* function;
	char** arguments;
	int arg_size;
	bool LOOP;

	unsigned char ERRNO;
}app_vars;

app_vars APPLICATION;


//void init(int func_length, int param_size, int* param_length);
//void setFunc(char* func);
//void setParam(char* param, int index);
void execute();

#endif
