#include <string.h>

#ifndef _ADDCHAR_H_
#define _ADDCHAR_H_

void addChar(char* str, char add);

#endif
