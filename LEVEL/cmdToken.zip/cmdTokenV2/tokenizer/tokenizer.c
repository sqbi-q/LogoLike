#include "./tokenizer.h"

extern app_vars APPLICATION;

void CMDT(char* str){
	const unsigned int LENGTH = strlen(str);
	const unsigned int FUNC_MAX_LENGTH = LENGTH;
	const unsigned int PARAMS_MAX_LENGTH = LENGTH;
	const unsigned int PARAMS_MAX_SIZE = LENGTH/2;

	unsigned int func_real_length = 0;
	unsigned int* param_real_length;
	param_real_length = malloc(LENGTH*sizeof(int));
	int i=0;
	while(i<LENGTH){
		param_real_length[i] = 0;
		i++;
	}

	unsigned int param_real_size = 0;

	i=0;
	int j=0;

	char func[FUNC_MAX_LENGTH];
	char params[PARAMS_MAX_SIZE][PARAMS_MAX_LENGTH];

	APPLICATION.function = (char*) malloc(FUNC_MAX_LENGTH * sizeof(char));
	APPLICATION.arguments = (char**) malloc(PARAMS_MAX_SIZE * sizeof(char*));
	while(i<PARAMS_MAX_SIZE){
		APPLICATION.arguments[i] = (char*) malloc(PARAMS_MAX_LENGTH * sizeof(char));
		strcpy(APPLICATION.arguments[i], "");
		i++;
	}
	strcpy(APPLICATION.function, "");

	i=0;
	while(i<LENGTH){
		while(str[i] != '[' && str[i] != '\0' &&
		str[i] != ' '){
			//addChar(func, str[i]);
			addChar(APPLICATION.function, tolower(str[i]));
			func_real_length++;
		 	i++;
		}
		if(str[i] == '['){
			i++;
			while(str[i] != ']'){
				addChar(APPLICATION.arguments[j], str[i]);
				param_real_length[j]++;
				i++;
	 		}i++;j++;
			param_real_size++;
		}
		if(str[i] == ' ') i++;
	}

	/*
	printf("\n\nFUNC: %s\n", func);
	printf("FUNC LEN: %d\nPARAM SIZE: %d\n",
	func_real_length, param_real_size);

	i=0;
	while(i < param_real_size){
		printf("PARAMLEN %d: %d\n",
		i, param_real_length[i]);
		printf("PARAM %s\n", params[i]);
		i++;
	}
	*/
	i=0;
	//printf("%s\n", func);
	//init(func_real_length, param_real_size, (int*) param_real_length);
	//printf("FUNC LENGTH: %d\nPARAM SIZE: %d\n", func_real_length, param_real_size);
	//setFunc(func);
	/*while(i<param_real_size){
		printf("PARAM %d LENGTH: %d\n", i, param_real_length[i]);
		setParam(params[i], i);
		i++;
	}*/

	//APPLICATION.func = (char*) malloc(func_real_length*sizeof(char));
	//APPLICATION.func = func;
	APPLICATION.arg_size = param_real_size;
	execute();
	/*while(i<param_real_size){
		printf("PARAM NR %d: %s\nPARAMLEN: %d\n",
		i, params[i], param_real_length[i]);
		i++;
	}*/

}
