#include "./addChar.h"

void addChar(char* str, char add){
        int length = strlen(str);
        str[length] = add;
        str[length+1] = '\0';
};
