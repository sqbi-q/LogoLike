#include "./addChar.h"
#include "../cmd-list/cmd-list.h"
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#ifndef _TOKENIZER_H_
#define _TOKENIZER_H_

void CMDT(char* str);

#endif
