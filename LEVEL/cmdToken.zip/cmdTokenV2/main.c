#include <stdio.h>
#include <stdlib.h>
#include "./tokenizer/tokenizer.h"
#include "./tokenizer/addChar.h"
#include "./intel_input/intel_input.h"
#include "./cmd-list/cmd-list.h"

extern app_vars APPLICATION;

int main(){
	CMDT("loop [true]");
	CMDT("echo [12345678]");
	CMDT("echo [TEST]");

	char* str;
	while(APPLICATION.LOOP){
		getInput(str);
		//printf("\n\n%s\n\n", str);
		CMDT(str);
	}

	return 0;
}
