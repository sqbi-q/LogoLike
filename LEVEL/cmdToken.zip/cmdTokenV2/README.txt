String tokenizer for basic "command executor"
author: sqbi#2735

Tested compilator (C language): clang-8


check cmd-list/ for creating custom commands
